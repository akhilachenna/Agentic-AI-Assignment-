"""
common/llm_client.py
---------------------
A single, unified LLM wrapper shared by every agent in this assignment.

Why this exists
================
All four tasks need to "call an LLM" at some point (to answer a question,
summarize a document, explain a threat, or write a report). Instead of
duplicating API code in every agent, we centralize it here.

Supported backends (auto-detected from environment variables):
    1. Anthropic Claude   -> set ANTHROPIC_API_KEY
    2. OpenAI GPT         -> set OPENAI_API_KEY
    3. Offline fallback   -> used automatically if no key is found.
       This lets every agent in this project run and be demoed WITHOUT
       any API key or internet access -- it uses simple extractive /
       rule-based text generation instead of a real LLM. This is clearly
       labeled in all output so it is never mistaken for a real LLM answer.

Usage
=====
    from common.llm_client import LLMClient
    llm = LLMClient()
    answer = llm.generate(system_prompt="...", user_prompt="...")
"""

import os
import re
import textwrap


class LLMClient:
    def __init__(self, model: str = None, temperature: float = 0.2):
        self.temperature = temperature
        self.backend = None
        self.model = model

        if os.environ.get("ANTHROPIC_API_KEY"):
            self.backend = "anthropic"
            self.model = model or "claude-sonnet-4-6"
            try:
                import anthropic  # noqa: F401
            except ImportError:
                print("[LLMClient] anthropic package not installed; "
                      "falling back to offline mode. Run: pip install anthropic")
                self.backend = "offline"

        elif os.environ.get("OPENAI_API_KEY"):
            self.backend = "openai"
            self.model = model or "gpt-4o-mini"
            try:
                import openai  # noqa: F401
            except ImportError:
                print("[LLMClient] openai package not installed; "
                      "falling back to offline mode. Run: pip install openai")
                self.backend = "offline"

        else:
            self.backend = "offline"

    # ------------------------------------------------------------------
    def generate(self, system_prompt: str, user_prompt: str, max_tokens: int = 1024) -> str:
        """Single entry point every agent calls. Returns plain text."""
        if self.backend == "anthropic":
            return self._call_anthropic(system_prompt, user_prompt, max_tokens)
        elif self.backend == "openai":
            return self._call_openai(system_prompt, user_prompt, max_tokens)
        else:
            return self._call_offline(system_prompt, user_prompt)

    # ------------------------------------------------------------------
    def _call_anthropic(self, system_prompt, user_prompt, max_tokens):
        import anthropic
        client = anthropic.Anthropic()
        resp = client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            temperature=self.temperature,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )
        return "".join(block.text for block in resp.content if block.type == "text")

    def _call_openai(self, system_prompt, user_prompt, max_tokens):
        from openai import OpenAI
        client = OpenAI()
        resp = client.chat.completions.create(
            model=self.model,
            max_tokens=max_tokens,
            temperature=self.temperature,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
        return resp.choices[0].message.content

    # ------------------------------------------------------------------
    def _call_offline(self, system_prompt, user_prompt):
        """
        Deterministic, dependency-free fallback so the whole project is
        runnable and demoable with zero API keys / zero internet.

        Strategy: naive extractive summarization -- score sentences in the
        prompt by keyword overlap with the instruction, and return the
        highest-scoring sentences. Not a real LLM, but keeps every agent's
        pipeline (retrieval -> "reasoning" -> structured output) fully
        functional for testing/demo purposes.
        """
        text = user_prompt
        # Pull out anything that looks like the actual content to summarize
        sentences = re.split(r'(?<=[.!?])\s+', text.replace("\n", " "))
        sentences = [s.strip() for s in sentences if len(s.strip()) > 20]

        if not sentences:
            return ("[OFFLINE MODE - no LLM API key configured] "
                    "No content available to summarize.")

        # crude keyword frequency scoring
        words = re.findall(r"[a-zA-Z]{4,}", text.lower())
        stop = {"this", "that", "with", "from", "have", "will", "your",
                "about", "into", "which", "these", "those", "there"}
        freq = {}
        for w in words:
            if w in stop:
                continue
            freq[w] = freq.get(w, 0) + 1

        def score(s):
            ws = re.findall(r"[a-zA-Z]{4,}", s.lower())
            return sum(freq.get(w, 0) for w in ws)

        ranked = sorted(sentences, key=score, reverse=True)
        top = ranked[: min(5, len(ranked))]
        # keep original order for readability
        top_in_order = [s for s in sentences if s in top]

        summary = " ".join(top_in_order)
        banner = ("[OFFLINE FALLBACK MODE -- no ANTHROPIC_API_KEY or "
                   "OPENAI_API_KEY found. This is a simple extractive "
                   "summary, NOT a real LLM response. Set an API key in "
                   ".env to get real generative answers.]\n\n")
        return banner + textwrap.fill(summary, width=100)
