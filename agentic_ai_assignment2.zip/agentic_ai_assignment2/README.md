# Applied Agentic AI -- Coding Assignment 2

This project implements all four required agents, each in its own folder,
plus a shared LLM wrapper used by all of them.

```
agentic_ai_assignment2/
├── README.md                     <- you are here
├── requirements.txt
├── .env.example
├── common/
│   └── llm_client.py              # shared LLM wrapper (Anthropic / OpenAI / offline)
├── task1_document_qa_agent/       # 1. RAG document Q&A agent
│   ├── document_qa_agent.py
│   └── sample_docs/company_policy.txt
├── task2_research_agent/          # 2. web research + report agent
│   └── research_agent.py
├── task3_security_log_agent/      # 3. security log/alert analysis agent
│   ├── security_log_agent.py
│   └── sample_logs/sample_auth.log
└── task4_multi_agent_system/      # 4. 3-agent collaborative pipeline
    └── multi_agent_system.py
```

## 0. Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# then edit .env and add ONE of:
#   ANTHROPIC_API_KEY=sk-ant-...
#   OPENAI_API_KEY=sk-...
```

**Important -- no API key is required to run/grade this project.** Every
agent uses `common/llm_client.py`, which automatically detects whether
`ANTHROPIC_API_KEY` or `OPENAI_API_KEY` is set:

* **If a key is set** → the agent calls the real LLM (Claude or GPT) for
  generation/reasoning steps.
* **If no key is set** → the agent automatically switches to a clearly
  labeled **OFFLINE FALLBACK MODE** that uses simple, dependency-free
  extractive summarization instead of a real LLM call. This keeps the full
  retrieval → reasoning → structured-output pipeline runnable end-to-end for
  testing/demoing without internet access or credentials. Every offline
  response is explicitly prefixed with `[OFFLINE FALLBACK MODE ...]` so it's
  never mistaken for a real model output.

Load the `.env` file however you prefer (e.g. `python-dotenv`, or simply
`export ANTHROPIC_API_KEY=...` in your shell) before running any script.

---

## Task 1 -- Document Q&A Agent (RAG)

**File:** `task1_document_qa_agent/document_qa_agent.py`

Reads PDF / DOCX / TXT / MD files, chunks them, builds a TF-IDF index
(scikit-learn, no external embedding API needed), retrieves the most
relevant chunks for a question via cosine similarity, and asks the LLM to
answer using only that retrieved context (classic RAG pattern).

```bash
python task1_document_qa_agent/document_qa_agent.py \
    --docs task1_document_qa_agent/sample_docs \
    --query "What is the refund policy after 90 days?"

# or interactively:
python task1_document_qa_agent/document_qa_agent.py \
    --docs task1_document_qa_agent/sample_docs --interactive
```

Drop your own PDFs into `sample_docs/` (or point `--docs` at any folder) to
try it with real documents.

---

## Task 2 -- Research Agent

**File:** `task2_research_agent/research_agent.py`

Pipeline: **SEARCH → SUMMARIZE each source → SYNTHESIZE → Markdown report
with references.**

```bash
python task2_research_agent/research_agent.py \
    --topic "impact of AI agents on cybersecurity" \
    --num_sources 5 \
    --out report.md
```

Uses `duckduckgo_search` for real web search (no API key needed for
search itself). If it's unavailable (no internet, package not installed),
the agent automatically substitutes a small labeled demo dataset so the
summarize → synthesize → report pipeline can still be verified.

---

## Task 3 -- Security Log / Alert Analysis Agent

**File:** `task3_security_log_agent/security_log_agent.py`

Fully self-contained, no internet or API key required to see real results
(LLM is only used to add a plain-English explanation per finding; falls
back to rule text if no key is set).

Detects, via a rule engine:
* Brute-force login attempts (many failures from one IP)
* Successful login following multiple failures (possible compromise)
* Port scans
* SQL injection signatures
* Privilege escalation events
* Malware/EDR signatures

Each finding is classified **LOW / MEDIUM / HIGH / CRITICAL** and paired
with concrete mitigation steps.

```bash
python task3_security_log_agent/security_log_agent.py \
    --log task3_security_log_agent/sample_logs/sample_auth.log \
    --json result.json
```

---

## Task 4 -- Multi-Agent Collaborative System

**File:** `task4_multi_agent_system/multi_agent_system.py`

Three specialized agents collaborate via a shared "blackboard" dict, run in
sequence by a small `Orchestrator` class:

1. **ResearchAgent** -- gathers raw information on the task (reuses Task 2's
   search logic).
2. **AnalystAgent** -- reviews the research and produces structured
   insights, risks, and a priority rating.
3. **ReportAgent** -- turns the analyst's notes into a polished final
   Markdown report, including a full agent-collaboration log.

```bash
python task4_multi_agent_system/multi_agent_system.py \
    --task "Evaluate whether our support team should adopt an AI ticket-triage agent" \
    --out final_report.md
```

### Why this design for Task 4
A shared blackboard (a single dict passed between agents) is the simplest
correct way to demonstrate multi-agent *collaboration* without pulling in a
heavyweight framework: each agent has one clear responsibility, reads what
the previous agent produced, and writes its own contribution back for the
next agent -- exactly the "specialized agents collaborating on a shared
task" pattern the assignment asks for. It can be swapped for LangGraph /
CrewAI / AutoGen later without changing each agent's internal logic.

---

## Design notes common to all four agents

* **No hard dependency on a paid API to run/demo** -- every agent degrades
  gracefully to an offline mode, clearly labeled, so grading/testing is not
  blocked by missing credentials or a sandboxed network.
* **Single shared LLM wrapper** (`common/llm_client.py`) avoids duplicating
  API glue code across tasks and makes it trivial to switch between Claude
  and GPT backends by only changing an environment variable.
* **Everything is runnable from the CLI** with `--help` on every script for
  the full list of options.
