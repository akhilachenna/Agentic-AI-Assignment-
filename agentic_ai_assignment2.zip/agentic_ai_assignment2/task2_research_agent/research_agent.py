"""
Task 2: Research Agent
=======================
Searches the web for a topic, fetches and summarizes the top sources, and
writes a structured Markdown research report complete with a references
section.

Pipeline: SEARCH -> FETCH -> SUMMARIZE (per source) -> SYNTHESIZE -> REPORT

Usage
-----
    python research_agent.py --topic "impact of AI on cybersecurity" --num_sources 5 --out report.md

Notes
-----
- Web search uses the `duckduckgo_search` package (no API key required).
- If duckduckgo_search or internet access is unavailable, the agent falls
  back to a small built-in demo dataset so the pipeline can still be run
  and inspected end-to-end offline.
- Summarization/synthesis uses common.llm_client.LLMClient (real LLM if a
  key is configured, otherwise a labeled offline extractive fallback).
"""

import os
import sys
import argparse
import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from common.llm_client import LLMClient  # noqa: E402


# ---------------------------------------------------------------------
# 1. Search
# ---------------------------------------------------------------------
def web_search(topic: str, num_results: int = 5):
    """Returns list of {title, url, snippet}. Falls back to a demo dataset
    if duckduckgo_search / internet is not available."""
    try:
        from duckduckgo_search import DDGS
        results = []
        with DDGS() as ddgs:
            for r in ddgs.text(topic, max_results=num_results):
                results.append({
                    "title": r.get("title", "Untitled"),
                    "url": r.get("href", ""),
                    "snippet": r.get("body", ""),
                })
        if results:
            return results
        raise RuntimeError("No results returned")
    except Exception as e:
        print(f"[research_agent] Live web search unavailable ({e}). "
              f"Using offline demo dataset instead.")
        return _offline_demo_results(topic, num_results)


def _offline_demo_results(topic: str, num_results: int):
    """Deterministic offline stand-in so the pipeline is fully runnable
    without internet access, clearly labeled as demo data."""
    base = [
        {
            "title": f"{topic.title()} -- Overview and Key Concepts",
            "url": "https://example.org/demo-source-1",
            "snippet": (f"{topic} has become an increasingly important area of study. "
                        f"Researchers highlight several core drivers behind its growth, "
                        f"including improved tooling, greater adoption, and rising demand "
                        f"for automation across industries."),
        },
        {
            "title": f"Recent Developments in {topic.title()}",
            "url": "https://example.org/demo-source-2",
            "snippet": (f"Recent developments in {topic} show a shift toward more "
                        f"integrated, agentic approaches. Experts note that organizations "
                        f"adopting these methods report efficiency gains, though challenges "
                        f"around governance and reliability remain."),
        },
        {
            "title": f"Challenges and Risks of {topic.title()}",
            "url": "https://example.org/demo-source-3",
            "snippet": (f"Despite rapid progress, {topic} faces challenges including data "
                        f"quality issues, regulatory uncertainty, and the need for robust "
                        f"evaluation frameworks to ensure safe deployment."),
        },
        {
            "title": f"Industry Applications of {topic.title()}",
            "url": "https://example.org/demo-source-4",
            "snippet": (f"Industries applying {topic} range from healthcare to finance. "
                        f"Case studies suggest measurable ROI when the technology is "
                        f"paired with strong human oversight and clear success metrics."),
        },
        {
            "title": f"Future Outlook for {topic.title()}",
            "url": "https://example.org/demo-source-5",
            "snippet": (f"Analysts forecast continued investment in {topic} over the next "
                        f"five years, driven by competitive pressure and maturing "
                        f"standards bodies working to formalize best practices."),
        },
    ]
    print("[research_agent] NOTE: These are placeholder demo sources "
          "(example.org), not real search results. Connect internet + "
          "duckduckgo_search to get live results.")
    return base[:num_results]


# ---------------------------------------------------------------------
# 2. The Agent
# ---------------------------------------------------------------------
class ResearchAgent:
    def __init__(self):
        self.llm = LLMClient()

    def summarize_source(self, topic: str, source: dict) -> str:
        system_prompt = (
            "You are a research analyst. Summarize the given source in 2-3 "
            "sentences, focused specifically on how it relates to the research "
            "topic. Be factual and neutral."
        )
        user_prompt = (
            f"RESEARCH TOPIC: {topic}\n\n"
            f"SOURCE TITLE: {source['title']}\n"
            f"SOURCE CONTENT: {source['snippet']}\n\n"
            f"Write a concise 2-3 sentence summary of this source's relevance to the topic."
        )
        return self.llm.generate(system_prompt, user_prompt, max_tokens=300)

    def synthesize(self, topic: str, source_summaries: list) -> str:
        system_prompt = (
            "You are a senior research analyst writing an executive summary. "
            "Combine the individual source summaries into 3-5 sentences that "
            "capture the overall state of the topic, key themes, and any "
            "tensions/disagreements across sources."
        )
        joined = "\n".join(f"- {s}" for s in source_summaries)
        user_prompt = f"RESEARCH TOPIC: {topic}\n\nSOURCE SUMMARIES:\n{joined}\n\nEXECUTIVE SUMMARY:"
        return self.llm.generate(system_prompt, user_prompt, max_tokens=400)

    def run(self, topic: str, num_sources: int = 5):
        print(f"[ResearchAgent] Searching for: {topic}")
        sources = web_search(topic, num_sources)

        print(f"[ResearchAgent] Summarizing {len(sources)} source(s)...")
        findings = []
        for src in sources:
            summary = self.summarize_source(topic, src)
            findings.append({**src, "summary": summary})

        print("[ResearchAgent] Synthesizing executive summary...")
        exec_summary = self.synthesize(topic, [f["summary"] for f in findings])

        report = self.build_report(topic, exec_summary, findings)
        return report

    # -----------------------------------------------------------------
    def build_report(self, topic: str, exec_summary: str, findings: list) -> str:
        date_str = datetime.date.today().isoformat()
        lines = []
        lines.append(f"# Research Report: {topic}")
        lines.append(f"*Generated on {date_str} by ResearchAgent*\n")
        lines.append("## Executive Summary")
        lines.append(exec_summary + "\n")
        lines.append("## Key Findings")
        for i, f in enumerate(findings, 1):
            lines.append(f"### {i}. {f['title']}")
            lines.append(f["summary"] + "\n")
        lines.append("## References")
        for i, f in enumerate(findings, 1):
            lines.append(f"[{i}] {f['title']} -- {f['url']}")
        return "\n".join(lines)


# ---------------------------------------------------------------------
# 3. CLI
# ---------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Task 2: Research Agent")
    parser.add_argument("--topic", required=True, help="Research topic/question")
    parser.add_argument("--num_sources", type=int, default=5)
    parser.add_argument("--out", default=None, help="Path to write the Markdown report")
    args = parser.parse_args()

    agent = ResearchAgent()
    report = agent.run(args.topic, args.num_sources)

    print("\n" + "=" * 70)
    print(report)
    print("=" * 70)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"\nReport saved to {args.out}")


if __name__ == "__main__":
    main()
