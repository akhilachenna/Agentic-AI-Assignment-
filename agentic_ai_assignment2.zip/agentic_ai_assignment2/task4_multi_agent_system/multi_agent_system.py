"""
Task 4: Multi-Agent Collaborative System
==========================================
Three specialized agents collaborate through a simple orchestrator to
complete a task automatically, each with a clearly separated role:

    1. ResearchAgent  - gathers raw information on the task (reuses the
                         search logic from Task 2, with an offline fallback).
    2. AnalystAgent   - reviews the research, extracts key insights, flags
                         risks/opportunities, and assigns a simple
                         confidence/priority score.
    3. ReportAgent    - takes the analyst's structured findings and writes
                         the final polished Markdown deliverable.

Agents communicate through a shared "Blackboard" (a simple dict) that the
Orchestrator passes between them -- a common, easy-to-understand pattern
for multi-agent collaboration without needing an external framework.

Usage
-----
    python multi_agent_system.py --task "Evaluate the market for AI-powered customer support tools"
"""

import os
import sys
import argparse
import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from common.llm_client import LLMClient  # noqa: E402

# reuse the search + offline fallback logic from Task 2
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "task2_research_agent")))
from research_agent import web_search  # noqa: E402


# ---------------------------------------------------------------------
# Agent 1: ResearchAgent
# ---------------------------------------------------------------------
class ResearchAgent:
    """Gathers raw information relevant to the task."""

    name = "ResearchAgent"

    def __init__(self):
        self.llm = LLMClient()

    def run(self, blackboard: dict) -> dict:
        task = blackboard["task"]
        print(f"[{self.name}] Gathering information for: {task}")
        sources = web_search(task, num_results=4)

        summaries = []
        for src in sources:
            system_prompt = "You are a research assistant. Summarize the source in 1-2 sentences relevant to the task."
            user_prompt = f"TASK: {task}\n\nSOURCE: {src['title']}\n{src['snippet']}\n\nSummary:"
            summary = self.llm.generate(system_prompt, user_prompt, max_tokens=200)
            summaries.append({**src, "summary": summary})

        blackboard["research_findings"] = summaries
        blackboard["log"].append(f"{self.name} collected {len(summaries)} source(s).")
        return blackboard


# ---------------------------------------------------------------------
# Agent 2: AnalystAgent
# ---------------------------------------------------------------------
class AnalystAgent:
    """Reviews research findings and extracts structured insights."""

    name = "AnalystAgent"

    def __init__(self):
        self.llm = LLMClient()

    def run(self, blackboard: dict) -> dict:
        task = blackboard["task"]
        findings = blackboard.get("research_findings", [])
        print(f"[{self.name}] Analyzing {len(findings)} finding(s)...")

        joined = "\n".join(f"- ({f['title']}): {f['summary']}" for f in findings)
        system_prompt = (
            "You are a senior analyst. Given research findings, produce:\n"
            "1) 3-5 KEY INSIGHTS (bullet points)\n"
            "2) 2-3 RISKS or open questions\n"
            "3) An overall PRIORITY rating (Low/Medium/High) for acting on this.\n"
            "Format your answer with clear headers: KEY INSIGHTS:, RISKS:, PRIORITY:"
        )
        user_prompt = f"TASK: {task}\n\nRESEARCH FINDINGS:\n{joined}\n\nProvide your analysis:"
        analysis_text = self.llm.generate(system_prompt, user_prompt, max_tokens=500)

        blackboard["analysis"] = analysis_text
        blackboard["log"].append(f"{self.name} produced structured analysis.")
        return blackboard


# ---------------------------------------------------------------------
# Agent 3: ReportAgent
# ---------------------------------------------------------------------
class ReportAgent:
    """Writes the final polished deliverable from the analyst's output."""

    name = "ReportAgent"

    def __init__(self):
        self.llm = LLMClient()

    def run(self, blackboard: dict) -> dict:
        task = blackboard["task"]
        analysis = blackboard.get("analysis", "")
        findings = blackboard.get("research_findings", [])
        print(f"[{self.name}] Writing final report...")

        system_prompt = (
            "You are a report writer. Turn the analyst's notes into a short, "
            "polished executive summary paragraph (4-6 sentences) suitable for "
            "a management report. Be clear and professional."
        )
        user_prompt = f"TASK: {task}\n\nANALYST NOTES:\n{analysis}\n\nWrite the executive summary paragraph:"
        exec_summary = self.llm.generate(system_prompt, user_prompt, max_tokens=400)

        blackboard["log"].append(f"{self.name} compiled the final report.")

        report_lines = [
            f"# Multi-Agent Report: {task}",
            f"*Generated {datetime.date.today().isoformat()} by a 3-agent pipeline "
            f"(ResearchAgent -> AnalystAgent -> ReportAgent)*\n",
            "## Executive Summary",
            exec_summary.strip() + "\n",
            "## Analyst Findings",
            analysis.strip() + "\n",
            "## Sources Consulted",
        ]
        for i, f in enumerate(findings, 1):
            report_lines.append(f"[{i}] {f['title']} -- {f['url']}")

        report_lines.append("\n## Agent Collaboration Log")
        for entry in blackboard["log"]:
            report_lines.append(f"- {entry}")

        final_report = "\n".join(report_lines)
        blackboard["final_report"] = final_report
        return blackboard


# ---------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------
class Orchestrator:
    """Runs the agents in sequence, passing a shared blackboard between them."""

    def __init__(self):
        self.agents = [ResearchAgent(), AnalystAgent(), ReportAgent()]

    def run(self, task: str) -> dict:
        blackboard = {"task": task, "log": [f"Task received: {task}"]}
        for agent in self.agents:
            blackboard = agent.run(blackboard)
        return blackboard


# ---------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Task 4: Multi-Agent Collaborative System")
    parser.add_argument("--task", required=True, help="Task/question for the agent team to complete")
    parser.add_argument("--out", default=None, help="Optional path to save the final report")
    args = parser.parse_args()

    orchestrator = Orchestrator()
    blackboard = orchestrator.run(args.task)

    print("\n" + "=" * 70)
    print(blackboard["final_report"])
    print("=" * 70)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(blackboard["final_report"])
        print(f"\nReport saved to {args.out}")


if __name__ == "__main__":
    main()
