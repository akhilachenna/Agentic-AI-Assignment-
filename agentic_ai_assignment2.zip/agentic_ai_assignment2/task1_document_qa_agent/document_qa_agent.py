"""
Task 1: Document Q&A Agent (RAG)
================================
Reads PDFs/TXT/DOCX documents, chunks and indexes them, retrieves the most
relevant chunks for a user question (TF-IDF + cosine similarity -- no
external embedding API required), and asks an LLM to answer the question
using ONLY the retrieved context.

Usage
-----
    # answer a single question
    python document_qa_agent.py --docs sample_docs --query "What is the refund policy?"

    # interactive chat loop
    python document_qa_agent.py --docs sample_docs --interactive

Supported file types: .pdf, .txt, .md, .docx
"""

import os
import sys
import glob
import argparse

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from common.llm_client import LLMClient  # noqa: E402


# ---------------------------------------------------------------------
# 1. Document loading
# ---------------------------------------------------------------------
def load_text_from_file(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext == ".pdf":
            import pypdf
            reader = pypdf.PdfReader(path)
            return "\n".join(page.extract_text() or "" for page in reader.pages)
        elif ext == ".docx":
            import docx
            doc = docx.Document(path)
            return "\n".join(p.text for p in doc.paragraphs)
        elif ext in (".txt", ".md"):
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()
        else:
            print(f"[skip] Unsupported file type: {path}")
            return ""
    except Exception as e:
        print(f"[warn] Failed to read {path}: {e}")
        return ""


def load_documents(folder: str):
    """Returns list of dicts: {source, text}"""
    docs = []
    patterns = ["*.pdf", "*.txt", "*.md", "*.docx"]
    files = []
    for p in patterns:
        files.extend(glob.glob(os.path.join(folder, "**", p), recursive=True))
    for f in sorted(files):
        text = load_text_from_file(f)
        if text.strip():
            docs.append({"source": os.path.basename(f), "text": text})
    return docs


# ---------------------------------------------------------------------
# 2. Chunking
# ---------------------------------------------------------------------
def chunk_text(text: str, chunk_size: int = 800, overlap: int = 150):
    """Simple sliding-window chunker over characters (keeps it dependency-free)."""
    chunks = []
    start = 0
    n = len(text)
    while start < n:
        end = min(start + chunk_size, n)
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end == n:
            break
        start = end - overlap
    return chunks


# ---------------------------------------------------------------------
# 3. The Agent
# ---------------------------------------------------------------------
class DocumentQAAgent:
    def __init__(self, docs_folder: str, chunk_size: int = 800, overlap: int = 150, top_k: int = 4):
        self.top_k = top_k
        self.llm = LLMClient()
        raw_docs = load_documents(docs_folder)
        if not raw_docs:
            raise ValueError(f"No readable documents found in '{docs_folder}'.")

        self.chunks = []       # list of chunk text
        self.chunk_sources = []  # parallel list of source filenames
        for doc in raw_docs:
            for c in chunk_text(doc["text"], chunk_size, overlap):
                self.chunks.append(c)
                self.chunk_sources.append(doc["source"])

        print(f"[DocumentQAAgent] Indexed {len(raw_docs)} document(s) "
              f"into {len(self.chunks)} chunk(s).")

        self.vectorizer = TfidfVectorizer(stop_words="english")
        self.chunk_matrix = self.vectorizer.fit_transform(self.chunks)

    # -- retrieval -------------------------------------------------
    def retrieve(self, query: str, top_k: int = None):
        top_k = top_k or self.top_k
        q_vec = self.vectorizer.transform([query])
        sims = cosine_similarity(q_vec, self.chunk_matrix)[0]
        ranked_idx = sims.argsort()[::-1][:top_k]
        results = []
        for idx in ranked_idx:
            if sims[idx] <= 0:
                continue
            results.append({
                "text": self.chunks[idx],
                "source": self.chunk_sources[idx],
                "score": float(sims[idx]),
            })
        return results

    # -- generation --------------------------------------------------
    def answer(self, query: str, top_k: int = None):
        retrieved = self.retrieve(query, top_k)
        if not retrieved:
            return {
                "answer": "I couldn't find anything relevant to that question "
                          "in the provided documents.",
                "sources": [],
            }

        context = "\n\n".join(
            f"[Source: {r['source']}]\n{r['text']}" for r in retrieved
        )
        system_prompt = (
            "You are a precise document Q&A assistant. Answer the user's "
            "question using ONLY the provided context. If the answer is not "
            "contained in the context, say you don't have enough information. "
            "Always cite which source(s) you used."
        )
        user_prompt = f"CONTEXT:\n{context}\n\nQUESTION: {query}\n\nANSWER:"
        answer_text = self.llm.generate(system_prompt, user_prompt)

        return {
            "answer": answer_text,
            "sources": sorted(set(r["source"] for r in retrieved)),
            "retrieved_chunks": retrieved,
        }


# ---------------------------------------------------------------------
# 4. CLI
# ---------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Task 1: Document Q&A (RAG) Agent")
    parser.add_argument("--docs", required=True, help="Folder containing PDFs/TXT/DOCX")
    parser.add_argument("--query", help="A single question to ask")
    parser.add_argument("--interactive", action="store_true", help="Start interactive chat loop")
    parser.add_argument("--top_k", type=int, default=4, help="Number of chunks to retrieve")
    args = parser.parse_args()

    agent = DocumentQAAgent(args.docs, top_k=args.top_k)

    if args.interactive:
        print("\nInteractive mode. Type 'exit' to quit.\n")
        while True:
            q = input("You: ").strip()
            if q.lower() in ("exit", "quit"):
                break
            result = agent.answer(q)
            print(f"\nAgent: {result['answer']}")
            print(f"(Sources: {', '.join(result['sources'])})\n")
    elif args.query:
        result = agent.answer(args.query)
        print("\n--- ANSWER ---")
        print(result["answer"])
        print("\n--- SOURCES ---")
        print(", ".join(result["sources"]) or "None")
    else:
        parser.error("Provide --query \"...\" or use --interactive")


if __name__ == "__main__":
    main()
