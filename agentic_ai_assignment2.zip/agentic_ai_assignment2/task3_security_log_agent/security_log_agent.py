"""
Task 3: Security Log / Alert Analysis Agent
============================================
Parses security logs, detects potential threats using a rule engine,
classifies severity (LOW / MEDIUM / HIGH / CRITICAL), and suggests concrete
mitigation steps. Optionally uses an LLM to write a human-readable
explanation of each finding (falls back to a built-in offline explanation
if no LLM key is configured, so this agent is fully usable with zero
external dependencies).

Usage
-----
    python security_log_agent.py --log sample_logs/sample_auth.log
    python security_log_agent.py --log sample_logs/sample_auth.log --json out.json

Supported log style (this demo): OpenSSH-style auth logs, one line each:
    Sep  8 02:14:11 web01 sshd[1234]: Failed password for admin from 203.0.113.5 port 51321 ssh2
Also handles generic lines containing IPs + keywords (port scan, sql injection, etc.)
"""

import os
import re
import sys
import json
import argparse
import collections

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from common.llm_client import LLMClient  # noqa: E402


IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")

MITIGATIONS = {
    "brute_force": [
        "Block or rate-limit the offending IP address at the firewall/WAF.",
        "Enforce account lockout after N failed attempts.",
        "Enable multi-factor authentication (MFA) on all exposed services.",
        "Disable password-based SSH auth in favor of key-based auth.",
    ],
    "port_scan": [
        "Block the source IP at the perimeter firewall.",
        "Ensure unused ports/services are closed (reduce attack surface).",
        "Enable IDS/IPS signatures for scan detection (e.g., Snort/Suricata).",
    ],
    "sql_injection": [
        "Deploy/verify a Web Application Firewall (WAF) rule for SQLi patterns.",
        "Use parameterized queries / prepared statements in application code.",
        "Review and sanitize all user-supplied input server-side.",
    ],
    "privilege_escalation": [
        "Immediately review sudoers / admin group membership changes.",
        "Rotate credentials for the affected account.",
        "Enable alerting on privilege changes via SIEM.",
    ],
    "malware_signature": [
        "Isolate the affected host from the network immediately.",
        "Run full AV/EDR scan and capture forensic image if needed.",
        "Check for lateral movement to other hosts.",
    ],
    "successful_login_after_failures": [
        "Treat as a possible successful brute-force compromise -- verify with the account owner.",
        "Force password reset and re-enable MFA for the account.",
        "Review recent activity/sessions for that account.",
    ],
    "unknown": [
        "Escalate to SOC analyst for manual review.",
        "Correlate with other logs/SIEM alerts for context.",
    ],
}


# ---------------------------------------------------------------------
# 1. Parsing
# ---------------------------------------------------------------------
def parse_log_file(path: str):
    """Returns list of {line_no, raw, ip, event_type, extra}."""
    events = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            ip_match = IP_RE.search(line)
            ip = ip_match.group(0) if ip_match else None

            event_type = classify_line(line)
            events.append({
                "line_no": i,
                "raw": line,
                "ip": ip,
                "event_type": event_type,
            })
    return events


def classify_line(line: str) -> str:
    lower = line.lower()
    if "failed password" in lower or "authentication failure" in lower or "invalid user" in lower:
        return "failed_login"
    if "accepted password" in lower or "accepted publickey" in lower or "session opened" in lower:
        return "successful_login"
    if any(k in lower for k in ("union select", "' or '1'='1", "select * from", "drop table", "sql injection")):
        return "sql_injection"
    if any(k in lower for k in ("nmap", "port scan", "syn scan", "connection scan")):
        return "port_scan"
    if any(k in lower for k in ("sudo:", "added to group", "privilege escalation", "usermod")):
        return "privilege_escalation"
    if any(k in lower for k in ("trojan", "malware", "ransomware", "virus detected", "eicar")):
        return "malware_signature"
    return "other"


# ---------------------------------------------------------------------
# 2. Threat detection (rule engine)
# ---------------------------------------------------------------------
def detect_threats(events, brute_force_threshold: int = 4, window_note: str = "entire log window"):
    threats = []

    failed_by_ip = collections.defaultdict(list)
    success_by_ip = collections.defaultdict(list)

    for e in events:
        if e["ip"] and e["event_type"] == "failed_login":
            failed_by_ip[e["ip"]].append(e)
        elif e["ip"] and e["event_type"] == "successful_login":
            success_by_ip[e["ip"]].append(e)

    # Rule 1: Brute force -- many failed logins from one IP
    for ip, fails in failed_by_ip.items():
        if len(fails) >= brute_force_threshold:
            severity = "CRITICAL" if len(fails) >= 10 else "HIGH" if len(fails) >= 6 else "MEDIUM"
            threats.append({
                "type": "brute_force",
                "source_ip": ip,
                "severity": severity,
                "evidence_count": len(fails),
                "evidence_lines": [f["line_no"] for f in fails][:10],
                "description": (f"{len(fails)} failed login attempts detected from {ip} "
                                 f"({window_note})."),
            })

    # Rule 2: Successful login from an IP that also had failed attempts (possible compromise)
    for ip in success_by_ip:
        if ip in failed_by_ip and len(failed_by_ip[ip]) >= 3:
            threats.append({
                "type": "successful_login_after_failures",
                "source_ip": ip,
                "severity": "CRITICAL",
                "evidence_count": len(failed_by_ip[ip]) + len(success_by_ip[ip]),
                "evidence_lines": [e["line_no"] for e in failed_by_ip[ip] + success_by_ip[ip]][:10],
                "description": (f"IP {ip} had {len(failed_by_ip[ip])} failed logins "
                                 f"followed by a SUCCESSFUL login -- possible account compromise."),
            })

    # Rule 3: direct signature matches (sql injection, port scan, privesc, malware)
    direct_types = {
        "sql_injection": "HIGH",
        "port_scan": "MEDIUM",
        "privilege_escalation": "HIGH",
        "malware_signature": "CRITICAL",
    }
    grouped = collections.defaultdict(list)
    for e in events:
        if e["event_type"] in direct_types:
            grouped[(e["event_type"], e["ip"])].append(e)

    for (etype, ip), evs in grouped.items():
        threats.append({
            "type": etype,
            "source_ip": ip or "unknown",
            "severity": direct_types[etype],
            "evidence_count": len(evs),
            "evidence_lines": [e["line_no"] for e in evs][:10],
            "description": f"{len(evs)} log line(s) matched '{etype}' signature"
                            f"{f' from {ip}' if ip else ''}.",
        })

    # sort by severity, most critical first
    order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    threats.sort(key=lambda t: order.get(t["severity"], 4))
    return threats


# ---------------------------------------------------------------------
# 3. The Agent
# ---------------------------------------------------------------------
class SecurityLogAgent:
    def __init__(self, brute_force_threshold: int = 4):
        self.llm = LLMClient()
        self.brute_force_threshold = brute_force_threshold

    def explain_threat(self, threat: dict) -> str:
        system_prompt = (
            "You are a SOC (Security Operations Center) analyst assistant. "
            "Given a detected threat, explain in 1-2 plain-English sentences "
            "what likely happened and why it matters, for a report a manager "
            "could read quickly."
        )
        user_prompt = (
            f"Threat type: {threat['type']}\n"
            f"Severity: {threat['severity']}\n"
            f"Source IP: {threat['source_ip']}\n"
            f"Evidence count: {threat['evidence_count']}\n"
            f"Raw description: {threat['description']}\n\n"
            f"Explain this threat for a management report."
        )
        return self.llm.generate(system_prompt, user_prompt, max_tokens=200)

    def analyze(self, log_path: str):
        events = parse_log_file(log_path)
        threats = detect_threats(events, self.brute_force_threshold)

        for t in threats:
            t["explanation"] = self.explain_threat(t)
            t["mitigations"] = MITIGATIONS.get(t["type"], MITIGATIONS["unknown"])

        summary = {
            "total_lines_parsed": len(events),
            "total_threats_detected": len(threats),
            "by_severity": collections.Counter(t["severity"] for t in threats),
        }
        return {"summary": summary, "threats": threats}


# ---------------------------------------------------------------------
# 4. Reporting
# ---------------------------------------------------------------------
def print_report(result: dict):
    s = result["summary"]
    print("\n" + "=" * 70)
    print("SECURITY LOG ANALYSIS REPORT")
    print("=" * 70)
    print(f"Lines parsed:      {s['total_lines_parsed']}")
    print(f"Threats detected:  {s['total_threats_detected']}")
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
        print(f"  {sev:<9}: {s['by_severity'].get(sev, 0)}")
    print("-" * 70)

    for i, t in enumerate(result["threats"], 1):
        print(f"\n[{i}] {t['type'].upper()}  |  Severity: {t['severity']}  |  Source IP: {t['source_ip']}")
        print(f"    Evidence: {t['evidence_count']} matching line(s) -> {t['evidence_lines']}")
        print(f"    Explanation: {t['explanation']}")
        print("    Suggested mitigations:")
        for m in t["mitigations"]:
            print(f"      - {m}")
    print("\n" + "=" * 70)


def main():
    parser = argparse.ArgumentParser(description="Task 3: Security Log/Alert Analysis Agent")
    parser.add_argument("--log", required=True, help="Path to the log file to analyze")
    parser.add_argument("--brute_force_threshold", type=int, default=4)
    parser.add_argument("--json", default=None, help="Optional path to also write results as JSON")
    args = parser.parse_args()

    agent = SecurityLogAgent(brute_force_threshold=args.brute_force_threshold)
    result = agent.analyze(args.log)
    print_report(result)

    if args.json:
        serializable = dict(result)
        serializable["summary"] = dict(result["summary"])
        serializable["summary"]["by_severity"] = dict(result["summary"]["by_severity"])
        with open(args.json, "w") as f:
            json.dump(serializable, f, indent=2)
        print(f"\nJSON report saved to {args.json}")


if __name__ == "__main__":
    main()
