import React, { useState, useEffect } from 'react';
import { Database, Play, RefreshCw, AlertTriangle, CheckCircle, Table, ArrowRight, ShieldCheck, Cpu } from 'lucide-react';
import { retrieveSchemas, executeSql, SCHEMA_CATALOG } from '../services/sqliteService';
import { generateSqlFromPrompt, repairSqlPrompt } from '../services/llmEngine';

export default function SqlAgent({ initialPrompt, onHandoff }) {
  const [question, setQuestion] = useState(initialPrompt || 'How many orders were completed in USA and what is the total amount?');
  const [retrievedTables, setRetrievedTables] = useState([]);
  const [generatedSql, setGeneratedSql] = useState('');
  const [queryResult, setQueryResult] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeStep, setActiveStep] = useState(0); // 1: Retrieval, 2: Generation, 3: Execution, 4: Repair
  
  // Repair loop state
  const [isSelfHealing, setIsSelfHealing] = useState(false);
  const [repairAttempts, setRepairAttempts] = useState([]);
  const [forceBadQuery, setForceBadQuery] = useState(false);

  useEffect(() => {
    if (initialPrompt) {
      setQuestion(initialPrompt);
      handleRunPipeline(initialPrompt);
    } else {
      handleRunPipeline(question);
    }
  }, [initialPrompt]);

  const handleRunPipeline = async (queryText = question) => {
    setIsProcessing(true);
    setErrorMsg(null);
    setQueryResult(null);
    setRepairAttempts([]);
    setIsSelfHealing(false);

    // Step 1: Schema Retrieval
    setActiveStep(1);
    const tables = retrieveSchemas(queryText);
    setRetrievedTables(tables);

    // Step 2: Query Generation
    setActiveStep(2);
    await new Promise(r => setTimeout(r, 400));
    
    let sql = '';
    if (forceBadQuery) {
      // Simulate broken query to demonstrate repair loop from Page 2 of PDF
      sql = "SELECT id, country, INVALID_COL FROM customers WHERE status = Completed;";
    } else {
      sql = await generateSqlFromPrompt(queryText, tables);
    }
    setGeneratedSql(sql);

    // Step 3: Execution against WASM SQLite
    setActiveStep(3);
    await new Promise(r => setTimeout(r, 300));

    try {
      const rows = executeSql(sql);
      setQueryResult(rows);
      setIsProcessing(false);
    } catch (err) {
      // Step 4: Self-Healing Repair Trigger
      setActiveStep(4);
      setIsSelfHealing(true);
      setErrorMsg(err.message);

      // Execute repair loop
      await handleSelfHealingLoop(queryText, sql, err.message);
      setIsProcessing(false);
    }
  };

  const handleSelfHealingLoop = async (q, badSql, errStr) => {
    const attempts = [{ attempt: 1, sql: badSql, error: errStr }];
    
    // Call repair LLM prompt
    const { fixedSql, repairExplanation } = await repairSqlPrompt(q, badSql, errStr);
    
    try {
      const fixedRows = executeSql(fixedSql);
      setGeneratedSql(fixedSql);
      setQueryResult(fixedRows);
      setErrorMsg(null);
      attempts.push({ attempt: 2, sql: fixedSql, status: 'SUCCESS', explanation: repairExplanation });
    } catch (secondErr) {
      attempts.push({ attempt: 2, sql: fixedSql, error: secondErr.message });
    }

    setRepairAttempts(attempts);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner matching PDF Page 1 & 2 */}
      <div className="glass-card p-6 rounded-2xl border border-cyanNeon/30 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono font-bold text-cyanNeon bg-cyanNeon/10 px-2 py-0.5 rounded border border-cyanNeon/30">
                01 · SCHEMA-GROUNDED
              </span>
              <span className="text-xs font-mono text-slate-400">ask-any-data-33.lovable.app</span>
            </div>
            <h2 className="text-2xl font-extrabold text-white font-mono tracking-tight">Text-to-SQL Agent</h2>
            <p className="text-xs font-mono text-cyanNeon/80 mt-1">
              ▶ retrieval → generation → execution → self-repair
            </p>
            <p className="text-sm text-slate-300 mt-2 max-w-2xl">
              Embeds the question, retrieves relevant tables from a schema catalog, writes a read-only SQLite query, runs it against a live in-browser SQLite warehouse — and repairs itself if execution fails.
            </p>
          </div>

          <div className="flex flex-col gap-2 shrink-0">
            <button
              onClick={() => handleRunPipeline(question)}
              disabled={isProcessing}
              className="px-5 py-2.5 rounded-xl bg-cyanNeon hover:bg-cyan-400 text-black font-bold font-mono text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all glow-cyan disabled:opacity-50"
            >
              <Play className="w-4 h-4" />
              <span>Run SQL Agent</span>
            </button>

            {/* Bad Query Injector Toggle to test self-repair loop */}
            <button
              onClick={() => {
                setForceBadQuery(!forceBadQuery);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono border transition-all flex items-center justify-center gap-1.5 ${
                forceBadQuery
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Simulate Bad Query (Test Repair Loop)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Input Query Bar */}
      <div className="glass-card p-4 rounded-xl border border-slate-800">
        <label className="block text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">
          Warehouse Question (Plain English):
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            className="flex-1 px-4 py-2.5 bg-[#07090e] border border-slate-700 rounded-lg text-sm text-slate-100 font-mono focus:border-cyanNeon focus:outline-none"
            placeholder="e.g. List top 5 customers by total spend with signup dates"
          />
          <button
            onClick={() => handleRunPipeline(question)}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs font-semibold rounded-lg transition-all"
          >
            Execute
          </button>
        </div>
      </div>

      {/* 4-Step Pipeline Visualizer */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className={`p-4 rounded-xl border transition-all ${activeStep >= 1 ? 'bg-cyanNeon/10 border-cyanNeon/40' : 'bg-slate-900/50 border-slate-800'}`}>
          <div className="flex items-center gap-2 mb-2">
            <span className="w-6 h-6 rounded-full bg-cyanNeon text-black font-bold font-mono text-xs flex items-center justify-center">1</span>
            <span className="text-xs font-mono font-bold text-slate-200">Schema Retrieval</span>
          </div>
          <p className="text-[11px] text-slate-400">Embeds query & selects relevant tables from 7-table catalog.</p>
        </div>

        <div className={`p-4 rounded-xl border transition-all ${activeStep >= 2 ? 'bg-cyanNeon/10 border-cyanNeon/40' : 'bg-slate-900/50 border-slate-800'}`}>
          <div className="flex items-center gap-2 mb-2">
            <span className="w-6 h-6 rounded-full bg-cyanNeon text-black font-bold font-mono text-xs flex items-center justify-center">2</span>
            <span className="text-xs font-mono font-bold text-slate-200">Query Generation</span>
          </div>
          <p className="text-[11px] text-slate-400">Writes read-only SELECT / WITH SQLite query.</p>
        </div>

        <div className={`p-4 rounded-xl border transition-all ${activeStep >= 3 && !errorMsg ? 'bg-cyanNeon/10 border-cyanNeon/40' : 'bg-slate-900/50 border-slate-800'}`}>
          <div className="flex items-center gap-2 mb-2">
            <span className="w-6 h-6 rounded-full bg-cyanNeon text-black font-bold font-mono text-xs flex items-center justify-center">3</span>
            <span className="text-xs font-mono font-bold text-slate-200">WASM Execution</span>
          </div>
          <p className="text-[11px] text-slate-400">Runs query in client-side SQLite warehouse.</p>
        </div>

        <div className={`p-4 rounded-xl border transition-all ${isSelfHealing ? 'bg-amber-500/10 border-amber-500/40 glow-pink' : 'bg-slate-900/50 border-slate-800'}`}>
          <div className="flex items-center gap-2 mb-2">
            <span className={`w-6 h-6 rounded-full font-bold font-mono text-xs flex items-center justify-center ${isSelfHealing ? 'bg-amber-500 text-black' : 'bg-slate-800 text-slate-400'}`}>4</span>
            <span className="text-xs font-mono font-bold text-slate-200">Self-Healing Repair</span>
          </div>
          <p className="text-[11px] text-slate-400">Catches SqlError & regenerates query with error context.</p>
        </div>
      </div>

      {/* Main Grid: Left (Retrieved Schemas & SQL), Right (Results & Self-Healing Log) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Column: Schema Catalog & Generated SQL */}
        <div className="space-y-4">
          
          {/* Retrieved Schema Subset Card */}
          <div className="glass-card p-4 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono font-bold text-cyanNeon uppercase tracking-wider flex items-center gap-1.5">
                <Table className="w-4 h-4" /> RETRIEVED SCHEMA CONTEXT ({retrievedTables.length} Tables)
              </span>
              <span className="text-[10px] font-mono text-slate-400">Grounding catalog subset</span>
            </div>

            <div className="space-y-2">
              {retrievedTables.map(t => (
                <div key={t.name} className="p-3 bg-[#07090e] rounded-lg border border-slate-800/80">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-mono font-bold text-cyan-300">{t.name}</span>
                    <span className="text-[10px] font-mono text-slate-500">Relevance: High</span>
                  </div>
                  <p className="text-[11px] text-slate-400">{t.description}</p>
                  <p className="text-[10px] font-mono text-slate-500 mt-1 truncate">
                    Columns: {t.columns.map(c => c.split(' ')[0]).join(', ')}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Generated SQL Query Code Box matching text_to_sql.py from PDF */}
          <div className="glass-card p-4 rounded-xl border border-slate-800 font-mono">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-cyanNeon" /> Generated SQLite Query
              </span>
              <span className="text-[10px] text-slate-500">SELECT / WITH only</span>
            </div>

            <div className="bg-[#07090e] p-4 rounded-lg border border-slate-800 text-xs text-cyan-300 leading-relaxed font-code overflow-x-auto">
              <pre>{generatedSql || '-- Generating SQL query...'}</pre>
            </div>
          </div>

        </div>

        {/* Right Column: Execution Output & Self-Healing Repair View */}
        <div className="space-y-4">
          
          {/* Self-Healing Alert Box if repair loop ran */}
          {isSelfHealing && (
            <div className="glass-card p-4 rounded-xl border border-amber-500/40 bg-amber-500/5 space-y-3">
              <div className="flex items-center gap-2 text-amber-400 font-mono font-bold text-xs">
                <ShieldCheck className="w-4 h-4" />
                <span>SELF-HEALING REPAIR LOOP TRIGGERED</span>
              </div>
              <p className="text-xs text-slate-300">
                Initial query failed with SQLite exception. The agent fed the stack trace into a second grounded prompt and auto-repaired the SQL:
              </p>

              {repairAttempts.map((att, idx) => (
                <div key={idx} className="p-3 bg-[#07090e] rounded-lg border border-slate-800 text-xs font-mono space-y-1">
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Attempt #{att.attempt}</span>
                    {att.status === 'SUCCESS' ? (
                      <span className="text-green-400 font-bold flex items-center gap-1"><CheckCircle className="w-3 h-3" /> REPAIRED</span>
                    ) : (
                      <span className="text-rose-400 font-bold flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> FAILED</span>
                    )}
                  </div>
                  {att.error && <p className="text-rose-400 text-[11px]">Error: {att.error}</p>}
                  {att.explanation && <p className="text-cyanNeon text-[11px]">{att.explanation}</p>}
                </div>
              ))}
            </div>
          )}

          {/* WASM SQLite Query Results Table */}
          <div className="glass-card p-4 rounded-xl border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Database className="w-4 h-4 text-cyanNeon" /> WASM SQLite Execution Results
              </span>
              {queryResult && (
                <span className="text-[11px] font-mono text-emerald-400 font-semibold bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40">
                  {queryResult.length} rows returned
                </span>
              )}
            </div>

            {queryResult && queryResult.length > 0 ? (
              <div className="overflow-x-auto max-h-64 rounded-lg border border-slate-800">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-slate-900/90 text-cyan-300 border-b border-slate-800 sticky top-0">
                    <tr>
                      {Object.keys(queryResult[0]).map((col) => (
                        <th key={col} className="px-3 py-2 border-r border-slate-800 font-semibold">{col}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 bg-[#07090e] text-slate-300">
                    {queryResult.map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-slate-900/50">
                        {Object.values(row).map((val, cIdx) => (
                          <td key={cIdx} className="px-3 py-2 border-r border-slate-800/60 whitespace-nowrap">
                            {val !== null && val !== undefined ? String(val) : 'NULL'}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : isProcessing ? (
              <div className="p-8 text-center text-xs font-mono text-slate-500">
                Executing query on WASM database...
              </div>
            ) : (
              <div className="p-8 text-center text-xs font-mono text-slate-500">
                No rows returned or query pending execution.
              </div>
            )}

            {/* Hand-off Redirect Button */}
            {queryResult && queryResult.length > 0 && (
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex justify-end">
                <button
                  onClick={() => onHandoff('summarizer', `Summarize these SQL query results into an executive summary:\n${JSON.stringify(queryResult, null, 2)}`)}
                  className="px-3.5 py-1.5 rounded-lg bg-greenNeon/15 hover:bg-greenNeon/25 text-greenNeon border border-greenNeon/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all"
                >
                  <span>Redirect & Pass Results to Summarizer Agent</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

          </div>

        </div>

      </div>

    </div>
  );
}
