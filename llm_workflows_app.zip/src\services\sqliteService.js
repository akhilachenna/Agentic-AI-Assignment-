import alasql from 'alasql';

// Initialize embedded in-browser database schema matching the PDF catalog
export const SCHEMA_CATALOG = [
  {
    name: 'customers',
    description: 'Signup date, country, marketing channel, loyalty tier, total spend',
    columns: ['id INT PRIMARY KEY', 'signup_date DATE', 'country VARCHAR', 'marketing_channel VARCHAR', 'loyalty_tier VARCHAR', 'total_spend DECIMAL'],
    sampleData: [
      { id: 1, signup_date: '2024-01-15', country: 'USA', marketing_channel: 'Google Ads', loyalty_tier: 'Gold', total_spend: 1450.50 },
      { id: 2, signup_date: '2024-02-01', country: 'Germany', marketing_channel: 'Organic', loyalty_tier: 'Silver', total_spend: 820.00 },
      { id: 3, signup_date: '2024-02-20', country: 'USA', marketing_channel: 'Email', loyalty_tier: 'Platinum', total_spend: 3400.00 },
      { id: 4, signup_date: '2024-03-05', country: 'UK', marketing_channel: 'Social', loyalty_tier: 'Bronze', total_spend: 210.00 },
      { id: 5, signup_date: '2024-03-12', country: 'Japan', marketing_channel: 'Affiliate', loyalty_tier: 'Gold', total_spend: 1890.75 }
    ]
  },
  {
    name: 'products',
    description: 'Category, unit price, cost, stock level',
    columns: ['id INT PRIMARY KEY', 'name VARCHAR', 'category VARCHAR', 'unit_price DECIMAL', 'cost DECIMAL', 'stock_level INT'],
    sampleData: [
      { id: 101, name: 'Cloud SQL Pro', category: 'Software', unit_price: 299.99, cost: 45.00, stock_level: 999 },
      { id: 102, name: 'Vector Hub Engine', category: 'Software', unit_price: 499.00, cost: 80.00, stock_level: 500 },
      { id: 103, name: 'Neural Accelerator Pod', category: 'Hardware', unit_price: 1299.00, cost: 750.00, stock_level: 42 },
      { id: 104, name: 'Agent Monitoring License', category: 'Software', unit_price: 99.00, cost: 10.00, stock_level: 1500 },
      { id: 105, name: 'Edge AI Sensor Kit', category: 'Hardware', unit_price: 349.50, cost: 180.00, stock_level: 120 }
    ]
  },
  {
    name: 'orders',
    description: 'Status, order date, shipping country',
    columns: ['id INT PRIMARY KEY', 'customer_id INT', 'status VARCHAR', 'order_date DATE', 'shipping_country VARCHAR', 'total_amount DECIMAL'],
    sampleData: [
      { id: 5001, customer_id: 1, status: 'Completed', order_date: '2024-03-01', shipping_country: 'USA', total_amount: 599.98 },
      { id: 5002, customer_id: 2, status: 'Shipped', order_date: '2024-03-02', shipping_country: 'Germany', total_amount: 499.00 },
      { id: 5003, customer_id: 3, status: 'Completed', order_date: '2024-03-04', shipping_country: 'USA', total_amount: 1798.00 },
      { id: 5004, customer_id: 4, status: 'Pending', order_date: '2024-03-05', shipping_country: 'UK', total_amount: 99.00 },
      { id: 5005, customer_id: 5, status: 'Completed', order_date: '2024-03-06', shipping_country: 'Japan', total_amount: 1648.50 }
    ]
  },
  {
    name: 'order_items',
    description: 'Product, units, unit price charged',
    columns: ['id INT PRIMARY KEY', 'order_id INT', 'product_id INT', 'units INT', 'unit_price DECIMAL'],
    sampleData: [
      { id: 1, order_id: 5001, product_id: 101, units: 2, unit_price: 299.99 },
      { id: 2, order_id: 5002, product_id: 102, units: 1, unit_price: 499.00 },
      { id: 3, order_id: 5003, product_id: 103, units: 1, unit_price: 1299.00 },
      { id: 4, order_id: 5003, product_id: 102, units: 1, unit_price: 499.00 },
      { id: 5, order_id: 5004, product_id: 104, units: 1, unit_price: 99.00 }
    ]
  },
  {
    name: 'payments',
    description: 'Method, amount, success flag',
    columns: ['id INT PRIMARY KEY', 'order_id INT', 'method VARCHAR', 'amount DECIMAL', 'success_flag BOOLEAN'],
    sampleData: [
      { id: 901, order_id: 5001, method: 'Credit Card', amount: 599.98, success_flag: true },
      { id: 902, order_id: 5002, method: 'PayPal', amount: 499.00, success_flag: true },
      { id: 903, order_id: 5003, method: 'Wire Transfer', amount: 1798.00, success_flag: true },
      { id: 904, order_id: 5004, method: 'Credit Card', amount: 99.00, success_flag: false },
      { id: 905, order_id: 5005, method: 'Apple Pay', amount: 1648.50, success_flag: true }
    ]
  },
  {
    name: 'support_tickets',
    description: 'Topic, priority, satisfaction score, resolution time',
    columns: ['id INT PRIMARY KEY', 'customer_id INT', 'topic VARCHAR', 'priority VARCHAR', 'satisfaction_score INT', 'resolution_time_hrs INT'],
    sampleData: [
      { id: 701, customer_id: 1, topic: 'API Rate Limits', priority: 'High', satisfaction_score: 5, resolution_time_hrs: 4 },
      { id: 702, customer_id: 2, topic: 'Billing Inquiry', priority: 'Medium', satisfaction_score: 4, resolution_time_hrs: 12 },
      { id: 703, customer_id: 4, topic: 'SDK Setup Issue', priority: 'High', satisfaction_score: 2, resolution_time_hrs: 48 },
      { id: 704, customer_id: 5, topic: 'Feature Request', priority: 'Low', satisfaction_score: 5, resolution_time_hrs: 24 }
    ]
  },
  {
    name: 'web_sessions',
    description: 'Device, page views, duration, conversion',
    columns: ['id INT PRIMARY KEY', 'customer_id INT', 'device VARCHAR', 'page_views INT', 'duration_sec INT', 'conversion BOOLEAN'],
    sampleData: [
      { id: 301, customer_id: 1, device: 'Desktop', page_views: 12, duration_sec: 640, conversion: true },
      { id: 302, customer_id: 2, device: 'Mobile', page_views: 4, duration_sec: 180, conversion: true },
      { id: 303, customer_id: 3, device: 'Desktop', page_views: 28, duration_sec: 1420, conversion: true },
      { id: 304, customer_id: 4, device: 'Tablet', page_views: 3, duration_sec: 95, conversion: false },
      { id: 305, customer_id: 5, device: 'Desktop', page_views: 19, duration_sec: 910, conversion: true }
    ]
  }
];

let isInitialized = false;

export function initDatabase() {
  if (isInitialized) return;
  try {
    SCHEMA_CATALOG.forEach(table => {
      alasql(`DROP TABLE IF EXISTS ${table.name}`);
      const colDef = table.columns.join(', ');
      alasql(`CREATE TABLE ${table.name} (${colDef})`);
      table.sampleData.forEach(row => {
        alasql(`INSERT INTO ${table.name} VALUES (${Object.values(row).map(v => typeof v === 'string' ? `'${v}'` : v).join(', ')})`);
      });
    });
    isInitialized = true;
    console.log('[SQLite WASM Engine] Database seeded successfully with 7 tables.');
  } catch (err) {
    console.error('Failed to initialize database:', err);
  }
}

export function executeSql(query) {
  initDatabase();
  const trimmed = query.trim();
  
  // Guard rule: SELECT or WITH only
  if (!/^(SELECT|WITH)\s/i.test(trimmed)) {
    throw new Error('Security Violation: Only read-only queries (SELECT or WITH) are allowed.');
  }
  
  try {
    const result = alasql(trimmed);
    return Array.isArray(result) ? result : [result];
  } catch (err) {
    throw new Error(`SqlError: ${err.message || 'Syntax error in SQL query'}`);
  }
}

// Retrieve relevant tables by keyword similarity / embedding match
export function retrieveSchemas(question) {
  const qLower = question.toLowerCase();
  
  // Vector-like schema retrieval algorithm matching question intent to table descriptions & names
  const scored = SCHEMA_CATALOG.map(table => {
    let score = 0;
    const tokens = [table.name, ...table.description.toLowerCase().split(/\W+/), ...table.columns.map(c => c.toLowerCase())];
    
    tokens.forEach(t => {
      if (t && qLower.includes(t)) score += 2;
    });

    if (qLower.includes('customer') || qLower.includes('user') || qLower.includes('who') || qLower.includes('country') || qLower.includes('spend')) {
      if (table.name === 'customers') score += 5;
    }
    if (qLower.includes('order') || qLower.includes('purchas') || qLower.includes('bought') || qLower.includes('sales')) {
      if (table.name === 'orders' || table.name === 'order_items') score += 5;
    }
    if (qLower.includes('product') || qLower.includes('item') || qLower.includes('price') || qLower.includes('stock') || qLower.includes('cost')) {
      if (table.name === 'products' || table.name === 'order_items') score += 5;
    }
    if (qLower.includes('pay') || qLower.includes('method') || qLower.includes('card') || qLower.includes('wire')) {
      if (table.name === 'payments') score += 5;
    }
    if (qLower.includes('ticket') || qLower.includes('support') || qLower.includes('satisfaction') || qLower.includes('issue')) {
      if (table.name === 'support_tickets') score += 5;
    }
    if (qLower.includes('session') || qLower.includes('device') || qLower.includes('traffic') || qLower.includes('view') || qLower.includes('convert')) {
      if (table.name === 'web_sessions') score += 5;
    }

    return { ...table, score };
  });

  scored.sort((a, b) => b.score - a.score);
  
  // Always return top relevant subset (at least 2, at most 4 tables)
  const result = scored.filter(s => s.score > 0);
  return result.length >= 2 ? result.slice(0, 4) : scored.slice(0, 3);
}
