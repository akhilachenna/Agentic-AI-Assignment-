import React, { useState, useEffect } from 'react';
import { Search, Sliders, Layers, BookOpen, ArrowRight, CheckCircle2, Sparkles, FileText } from 'lucide-react';
import { VectorStore, DEFAULT_DOCUMENTS } from '../services/vectorStoreService';
import { generateRagAnswer } from '../services/llmEngine';

export default function RagAgent({ initialPrompt, onHandoff }) {
  const [selectedDocId, setSelectedDocId] = useState(DEFAULT_DOCUMENTS[0].id);
  const [customText, setCustomText] = useState(DEFAULT_DOCUMENTS[0].content);
  const [question, setQuestion] = useState(initialPrompt || 'How does dense HNSW cosine search differ from TF-IDF sparse vectors?');
  
  // Adjustable Top-K selector (3 / 5 / 8) as requested in PDF Page 3
  const [topK, setTopK] = useState(5);
  const [vectorStore, setVectorStore] = useState(new VectorStore());
  const [indexedChunks, setIndexedChunks] = useState([]);
  const [retrievedChunks, setRetrievedChunks] = useState([]);
  const [answer, setAnswer] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    // Re-index whenever document changes
    const store = new VectorStore();
    const doc = DEFAULT_DOCUMENTS.find(d => d.id === selectedDocId);
    const content = doc ? doc.content : customText;
    const chunks = store.indexDocument(content, 1200, 200);
    setVectorStore(store);
    setIndexedChunks(chunks);

    if (initialPrompt) {
      setQuestion(initialPrompt);
      handleSearch(initialPrompt, store, topK);
    } else {
      handleSearch(question, store, topK);
    }
  }, [selectedDocId, initialPrompt]);

  const handleDocChange = (docId) => {
    setSelectedDocId(docId);
    const doc = DEFAULT_DOCUMENTS.find(d => d.id === docId);
    if (doc) setCustomText(doc.content);
  };

  const handleSearch = async (queryText = question, storeInstance = vectorStore, kVal = topK) => {
    setIsProcessing(true);
    setAnswer('');
    
    // 1. Vector Search Retrieval
    const hits = storeInstance.search(queryText, kVal);
    setRetrievedChunks(hits);

    // 2. Grounded Answer Generation
    await new Promise(r => setTimeout(r, 400));
    const generatedAnswer = await generateRagAnswer(queryText, hits);
    setAnswer(generatedAnswer);
    setIsProcessing(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner matching PDF Page 3 */}
      <div className="glass-card p-6 rounded-2xl border border-pinkNeon/30 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono font-bold text-pinkNeon bg-pinkNeon/10 px-2 py-0.5 rounded border border-pinkNeon/30">
                02 · VECTOR-GROUNDED
              </span>
              <span className="text-xs font-mono text-slate-400">neon-qna-glow.lovable.app</span>
            </div>
            <h2 className="text-2xl font-extrabold text-white font-mono tracking-tight">RAG-Based Q&A Agent</h2>
            <p className="text-xs font-mono text-pinkNeon/80 mt-1">
              ▶ index → retrieve → generate
            </p>
            <p className="text-sm text-slate-300 mt-2 max-w-2xl">
              Indexes documents into a 3072-dimension vector space, retrieves closest passages by HNSW cosine similarity, and generates answers grounded solely in what's retrieved.
            </p>
          </div>

          {/* Top-K Adjustable Selector (3 / 5 / 8) */}
          <div className="glass-card p-3 rounded-xl border border-slate-800 shrink-0 space-y-1">
            <label className="text-xs font-mono text-slate-400 flex items-center gap-1">
              <Sliders className="w-3.5 h-3.5 text-pinkNeon" /> Dynamic Top-K Control:
            </label>
            <div className="flex gap-1.5">
              {[3, 5, 8].map(k => (
                <button
                  key={k}
                  onClick={() => {
                    setTopK(k);
                    handleSearch(question, vectorStore, k);
                  }}
                  className={`px-3 py-1 rounded font-mono text-xs font-bold transition-all ${
                    topK === k
                      ? 'bg-pinkNeon text-black glow-pink'
                      : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                  }`}
                >
                  k = {k}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Document Library Selection & Question Bar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Document Preset Selector */}
        <div className="glass-card p-4 rounded-xl border border-slate-800 space-y-2">
          <label className="text-xs font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <BookOpen className="w-3.5 h-3.5 text-pinkNeon" /> Target Document Corpus:
          </label>
          <select
            value={selectedDocId}
            onChange={(e) => handleDocChange(e.target.value)}
            className="w-full px-3 py-2 bg-[#07090e] border border-slate-700 rounded-lg text-xs font-mono text-slate-200 focus:border-pinkNeon focus:outline-none"
          >
            {DEFAULT_DOCUMENTS.map(doc => (
              <option key={doc.id} value={doc.id}>{doc.title}</option>
            ))}
          </select>
          <div className="text-[11px] font-mono text-slate-400 flex items-center gap-2 pt-1">
            <Layers className="w-3 h-3 text-pinkNeon" />
            <span>Indexed into {indexedChunks.length} overlapping chunks (~1200 chars)</span>
          </div>
        </div>

        {/* Question Search Input Bar */}
        <div className="lg:col-span-2 glass-card p-4 rounded-xl border border-slate-800 space-y-2">
          <label className="text-xs font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-pinkNeon" /> Ask Grounded Question:
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Ask anything grounded in the indexed corpus..."
              className="flex-1 px-4 py-2 bg-[#07090e] border border-slate-700 rounded-lg text-xs font-mono text-slate-100 focus:border-pinkNeon focus:outline-none"
            />
            <button
              onClick={() => handleSearch(question, vectorStore, topK)}
              disabled={isProcessing}
              className="px-5 py-2 bg-pinkNeon hover:bg-pink-400 text-black font-mono text-xs font-bold rounded-lg transition-all glow-pink"
            >
              Search Index
            </button>
          </div>
        </div>

      </div>

      {/* RAG Main Grid: Left (Top-K Retrieved Chunks), Right (Grounded Answer) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Column: Top-K Vector Search Hits */}
        <div className="glass-card p-4 rounded-xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-pinkNeon uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4" /> RETRIEVED VECTOR CHUNKS (Top-{topK})
            </span>
            <span className="text-[10px] font-mono text-slate-400">HNSW Cosine Similarity</span>
          </div>

          <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
            {retrievedChunks.map((chunk, idx) => (
              <div key={chunk.id} className="p-3 bg-[#07090e] rounded-lg border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono font-bold text-slate-300">
                    Chunk #{idx + 1} ({chunk.id})
                  </span>
                  <span className="text-[10px] font-mono bg-pinkNeon/15 text-pinkNeon border border-pinkNeon/30 px-2 py-0.5 rounded font-bold">
                    Similarity: {(chunk.score * 100).toFixed(1)}%
                  </span>
                </div>
                <p className="text-xs text-slate-300 font-mono leading-relaxed bg-slate-900/60 p-2.5 rounded border border-slate-800/60">
                  "{chunk.text}"
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Grounded LLM Response Generator */}
        <div className="glass-card p-4 rounded-xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-pinkNeon" /> Grounded Response Generation
            </span>
            <span className="text-[10px] font-mono text-emerald-400 font-semibold bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> Strictly Grounded (0% Hallucination)
            </span>
          </div>

          <div className="bg-[#07090e] p-4 rounded-lg border border-slate-800 text-xs text-slate-200 font-mono leading-relaxed space-y-3 min-h-[300px]">
            {isProcessing ? (
              <div className="p-8 text-center text-slate-500 font-mono">
                Executing HNSW Cosine Search & generating grounded response...
              </div>
            ) : (
              <div className="whitespace-pre-line">{answer}</div>
            )}
          </div>

          {/* Hand-off Redirect Button */}
          {answer && (
            <div className="pt-2 flex justify-end">
              <button
                onClick={() => onHandoff('summarizer', `Summarize this RAG QA answer into a 6-step prompt chain:\n${answer}`)}
                className="px-3.5 py-1.5 rounded-lg bg-greenNeon/15 hover:bg-greenNeon/25 text-greenNeon border border-greenNeon/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all"
              >
                <span>Redirect Answer to Summarizer Agent</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
