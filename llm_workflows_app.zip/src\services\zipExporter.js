import JSZip from 'jszip';

export async function createCodebaseZip() {
  const zip = new JSZip();

  // Root files
  zip.file('package.json', `{
  "name": "llm-workflows-3-agents",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "lucide-react": "^0.453.0",
    "alasql": "^4.5.1",
    "jszip": "^3.10.1"
  },
  "devDependencies": {
    "@types/react": "^18.3.12",
    "@types/react-dom": "^18.3.1",
    "@vitejs/plugin-react": "^4.3.3",
    "autoprefixer": "^10.4.20",
    "postcss": "^8.4.47",
    "tailwindcss": "^3.4.14",
    "vite": "^5.4.10"
  }
}`);

  zip.file('vite.config.js', `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: { port: 3000 }
});`);

  zip.file('tailwind.config.js', `/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        dark: { 900: '#07090e', 800: '#0b0f19', 700: '#111827', 600: '#1f293d' },
        cyanNeon: '#00f2fe',
        pinkNeon: '#ff2a85',
        greenNeon: '#00ff87'
      }
    }
  },
  plugins: []
};`);

  zip.file('index.html', `<!DOCTYPE html>
<html lang="en" class="dark">
  <head>
    <meta charset="UTF-8" />
    <title>LLM Workflows — 3 Live Agents</title>
  </head>
  <body class="bg-[#07090e] text-slate-100 min-h-screen">
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>`);

  zip.file('README.md', `# LLM Workflows — Three Live Experiments Application

Deployed 3-agent orchestration suite featuring:
1. **Agent 01: Text-to-SQL Agent** with Schema Retrieval, WASM SQLite Execution, and Self-Healing Repair Loop.
2. **Agent 02: Vector-Grounded RAG QA Agent** with Dense HNSW Cosine Indexing, Overlapping Chunks, and Adjustable Top-K (3 / 5 / 8).
3. **Agent 03: Decomposed Prompt-Chain Summarizer** with 6 inspectable narrow steps, tone & length controls, and hallucination critique audit.
4. **Smart Intent Router Orchestrator**: Automatically classifies questions and seamlessly redirects tasks between agents.

## Getting Started
\`\`\`bash
npm install
npm run dev
\`\`\`
Open http://localhost:3000
`);

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'llm_workflows_3_agents.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
