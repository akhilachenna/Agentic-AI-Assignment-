# LLM Workflows — Three Deployed Agents & Smart Orchestrator

This repository contains a full production implementation of 3 LLM agents and a Smart Intent Router based on the reference architecture:

## 🤖 Deployed Agents
1. **Agent 01: Schema-Grounded Text-to-SQL Agent**
   - 7-table catalog (`customers`, `products`, `orders`, `order_items`, `payments`, `support_tickets`, `web_sessions`).
   - In-browser WASM SQLite execution engine.
   - Self-healing repair loop catching SQL errors and auto-repairing queries.

2. **Agent 02: Vector-Grounded RAG-Based Q&A Agent**
   - Overlapping text chunking (~1200 chars, 200 overlap).
   - Dense embedding & HNSW cosine similarity search.
   - Live adjustable Top-K selector (3 / 5 / 8).
   - Strictly grounded response generator (0% hallucination).

3. **Agent 03: Decomposed Prompt-Chain Summarizer Agent**
   - 6-step inspectable pipeline: Normalize → Extract Facts → Outline → Draft → Critique → Polish.
   - Configurable Tone (Neutral, Executive, Technical, Friendly) and Length (Tight, Standard, Detailed).
   - Fact audit step serving as ground truth.

4. **Smart Intent Router & Agent Redirection System**
   - Classifies user queries and automatically redirects tasks to the optimal agent with animated transitions.
   - Agent-to-Agent hand-off controls for passing data across workflows.

## 🚀 Getting Started

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Build for production
npm run build
```

Open `http://localhost:3000` to interact with the application.
