import React, { useState } from 'react';
import Navbar from './components/Navbar';
import OrchestratorBar from './components/OrchestratorBar';
import SqlAgent from './components/SqlAgent';
import RagAgent from './components/RagAgent';
import SummarizerAgent from './components/SummarizerAgent';
import SideBySideComparison from './components/SideBySideComparison';
import RedirectNotice from './components/RedirectNotice';
import ApiKeyModal from './components/ApiKeyModal';
import { API_SETTINGS } from './services/llmEngine';

export default function App() {
  const [activeAgent, setActiveAgent] = useState('sql'); // 'sql', 'rag', 'summarizer'
  const [agentPrompt, setAgentPrompt] = useState('');
  const [redirectNotice, setRedirectNotice] = useState(null);
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState(false);

  // Handle redirection from Orchestrator or Agent hand-offs
  const handleAgentRedirect = (targetAgent, promptText, reasoning) => {
    setActiveAgent(targetAgent);
    setAgentPrompt(promptText);
    setRedirectNotice({
      targetAgent,
      reasoning: reasoning || `Redirecting task context to Agent ${targetAgent === 'sql' ? '01 (Text-to-SQL)' : targetAgent === 'rag' ? '02 (RAG QA)' : '03 (Prompt-Chain Summarizer)'}`
    });

    // Auto dismiss toast notice after 5 seconds
    setTimeout(() => {
      setRedirectNotice(null);
    }, 5000);
  };

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 font-sans flex flex-col selection:bg-cyanNeon selection:text-black">
      
      {/* Top Header Navigation */}
      <Navbar
        activeAgent={activeAgent}
        setActiveAgent={setActiveAgent}
        onOpenApiKeyModal={() => setIsApiKeyModalOpen(true)}
        isSimulated={API_SETTINGS.provider === 'simulated'}
      />

      {/* Smart Orchestrator & Intent Router Input Bar */}
      <OrchestratorBar
        activeAgent={activeAgent}
        onRedirect={handleAgentRedirect}
      />

      {/* Main Content Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 lg:p-8 space-y-8">
        
        {/* Render Active Agent */}
        {activeAgent === 'sql' && (
          <SqlAgent
            initialPrompt={agentPrompt}
            onHandoff={(target, prompt) => handleAgentRedirect(target, prompt, `Handoff: Passing SQL query output into ${target === 'summarizer' ? 'Agent 03 Summarizer' : 'Agent 02 RAG'}.`)}
          />
        )}

        {activeAgent === 'rag' && (
          <RagAgent
            initialPrompt={agentPrompt}
            onHandoff={(target, prompt) => handleAgentRedirect(target, prompt, `Handoff: Passing RAG answer into ${target === 'summarizer' ? 'Agent 03 Summarizer' : 'Agent 01 Text-to-SQL'}.`)}
          />
        )}

        {activeAgent === 'summarizer' && (
          <SummarizerAgent
            initialPrompt={agentPrompt}
            onHandoff={(target, prompt) => handleAgentRedirect(target, prompt, `Handoff: Passing summarized artifact into ${target === 'rag' ? 'Agent 02 RAG Vector Index' : 'Agent 01 Text-to-SQL'}.`)}
          />
        )}

        {/* Architectural Side-by-side Matrix (PDF Page 5) */}
        <SideBySideComparison />

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-[#07090e] py-6 px-4 text-center font-mono text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>APPLIED LLM ENGINEERING · 3 LIVE EXPERIMENTS & REDIRECTOR</span>
          <span className="text-cyanNeon">Reference Architecture Shipped & Deployed</span>
        </div>
      </footer>

      {/* Redirection Toast Notice */}
      <RedirectNotice
        notice={redirectNotice}
        onClose={() => setRedirectNotice(null)}
      />

      {/* API Key Modal */}
      <ApiKeyModal
        isOpen={isApiKeyModalOpen}
        onClose={() => setIsApiKeyModalOpen(false)}
      />

    </div>
  );
}
