import React, { useState } from 'react';
import { Key, X, Check, Shield } from 'lucide-react';
import { setApiKey, API_SETTINGS } from '../services/llmEngine';

export default function ApiKeyModal({ isOpen, onClose }) {
  const [provider, setProvider] = useState(API_SETTINGS.provider);
  const [keyInput, setKeyInput] = useState(API_SETTINGS.apiKey);
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSave = (e) => {
    e.preventDefault();
    setApiKey(provider, keyInput);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="glass-card w-full max-w-md p-6 rounded-2xl border border-slate-700 shadow-2xl relative space-y-4">
        
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Key className="w-5 h-5 text-yellow-400" />
            <h3 className="text-base font-mono font-bold text-white">LLM Provider & API Key Config</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-4 font-mono text-xs">
          
          <div className="space-y-2">
            <label className="block text-slate-300">Select LLM Engine:</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'simulated', label: 'Offline Simulator (Built-in)' },
                { id: 'gemini', label: 'Google Gemini' },
                { id: 'openai', label: 'OpenAI GPT-4' }
              ].map(item => (
                <button
                  type="button"
                  key={item.id}
                  onClick={() => setProvider(item.id)}
                  className={`p-2.5 rounded-lg border text-center transition-all ${
                    provider === item.id
                      ? 'bg-cyanNeon/15 text-cyanNeon border border-cyanNeon/50 font-bold'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {provider !== 'simulated' && (
            <div className="space-y-2">
              <label className="block text-slate-300">Enter {provider.toUpperCase()} API Key:</label>
              <input
                type="password"
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                placeholder="sk-..."
                className="w-full px-3 py-2.5 bg-[#07090e] border border-slate-700 rounded-lg text-slate-100 focus:border-cyanNeon focus:outline-none"
              />
              <p className="text-[10px] text-slate-500 flex items-center gap-1">
                <Shield className="w-3 h-3 text-cyanNeon" /> Keys are stored strictly in client memory during your session.
              </p>
            </div>
          )}

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 border border-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-cyanNeon hover:bg-cyan-400 text-black font-bold flex items-center gap-1.5 transition-all"
            >
              {savedSuccess ? <Check className="w-4 h-4" /> : null}
              <span>{savedSuccess ? 'Saved!' : 'Save Configuration'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}
