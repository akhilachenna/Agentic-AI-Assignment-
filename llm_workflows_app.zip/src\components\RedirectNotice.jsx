import React from 'react';
import { ArrowRight, Sparkles, X } from 'lucide-react';

export default function RedirectNotice({ notice, onClose }) {
  if (!notice) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-md glass-card p-4 rounded-xl border border-cyanNeon/50 glow-cyan shadow-2xl animate-bounce-short">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-cyanNeon/20 border border-cyanNeon flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-cyanNeon" />
          </div>
          <div>
            <span className="text-[10px] font-mono font-bold text-cyanNeon uppercase tracking-wider">
              AGENT REDIRECTION TRIGGERED
            </span>
            <h4 className="text-xs font-mono font-semibold text-slate-100 mt-0.5">
              {notice.reasoning}
            </h4>
          </div>
        </div>

        <button
          onClick={onClose}
          className="text-slate-400 hover:text-slate-200 text-xs p-1"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
