import React from 'react';
import { Database, Search, GitMerge, Cpu, Layers } from 'lucide-react';

export default function SideBySideComparison() {
  return (
    <section className="glass-card p-6 rounded-2xl border border-slate-800 space-y-6">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h3 className="text-lg font-mono font-bold text-white tracking-tight flex items-center gap-2">
            <Layers className="w-5 h-5 text-cyanNeon" /> Side-by-side Experiments Matrix
          </h3>
          <p className="text-xs font-mono text-slate-400">Direct architecture comparison from build log reference</p>
        </div>
        <span className="text-[10px] font-mono bg-cyanNeon/10 text-cyanNeon border border-cyanNeon/30 px-2 py-1 rounded">
          REFERENCE ARCHITECTURE
        </span>
      </div>

      {/* Comparison Table matching PDF Page 5 */}
      <div className="overflow-x-auto rounded-xl border border-slate-800 font-mono text-xs">
        <table className="w-full text-left">
          <thead className="bg-slate-900 text-slate-300 border-b border-slate-800 uppercase tracking-wider text-[11px]">
            <tr>
              <th className="px-4 py-3 border-r border-slate-800 font-bold text-cyanNeon">EXPERIMENT</th>
              <th className="px-4 py-3 border-r border-slate-800 font-bold text-pinkNeon">DATA FED TO THE LLM</th>
              <th className="px-4 py-3 font-bold text-greenNeon">DISTINGUISHING FEATURE</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800 bg-[#07090e] text-slate-300">
            <tr className="hover:bg-slate-900/40">
              <td className="px-4 py-3 font-bold border-r border-slate-800 text-cyan-300 flex items-center gap-2">
                <Database className="w-4 h-4 text-cyanNeon" /> Text-to-SQL Agent
              </td>
              <td className="px-4 py-3 border-r border-slate-800 text-slate-300">
                Question + embedding-retrieved tables from a 7-table catalog
              </td>
              <td className="px-4 py-3 text-slate-300">
                <span className="text-cyanNeon font-semibold">Self-healing:</span> repairs a query that fails to execute against in-browser WASM SQLite
              </td>
            </tr>

            <tr className="hover:bg-slate-900/40">
              <td className="px-4 py-3 font-bold border-r border-slate-800 text-pink-300 flex items-center gap-2">
                <Search className="w-4 h-4 text-pinkNeon" /> RAG-Based Q&A
              </td>
              <td className="px-4 py-3 border-r border-slate-800 text-slate-300">
                Question + top-k chunks from a 3072-d HNSW cosine index
              </td>
              <td className="px-4 py-3 text-slate-300">
                <span className="text-pinkNeon font-semibold">Adjustable top-k (3 / 5 / 8)</span> at query time rather than fixed default
              </td>
            </tr>

            <tr className="hover:bg-slate-900/40">
              <td className="px-4 py-3 font-bold border-r border-slate-800 text-green-300 flex items-center gap-2">
                <GitMerge className="w-4 h-4 text-greenNeon" /> Prompt-Chain Summarizer
              </td>
              <td className="px-4 py-3 border-r border-slate-800 text-slate-300">
                Source text, then each of 6 sequential steps' own output
              </td>
              <td className="px-4 py-3 text-slate-300">
                <span className="text-greenNeon font-semibold">Adjustable tone + length;</span> critique step audits for hallucination against facts
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Common Foundation Card matching PDF Page 5 */}
      <div className="p-5 rounded-xl border border-cyanNeon/30 bg-gradient-to-r from-cyanNeon/10 via-purpleNeon/10 to-pinkNeon/10 text-xs font-mono space-y-2">
        <h4 className="text-sm font-bold text-white flex items-center gap-2">
          <Cpu className="w-4 h-4 text-cyanNeon" /> Common Foundation
        </h4>
        <p className="text-slate-300 leading-relaxed">
          All three experiments share the same underlying move — ground a call in the right data, or split a task into simpler sequential calls. Text-to-SQL grounds generation in a retrieved schema; RAG-based Q&A grounds it in retrieved document chunks; the summarizer decomposes one large task into six narrow, inspectable steps. Real vector retrieval instead of TF-IDF, a self-repair loop instead of a single shot, a deeper six-link chain instead of four.
        </p>
      </div>

    </section>
  );
}
