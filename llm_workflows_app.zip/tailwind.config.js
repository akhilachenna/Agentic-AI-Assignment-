/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        dark: {
          900: '#07090e',
          800: '#0b0f19',
          700: '#111827',
          600: '#1f293d',
          500: '#2d3748',
        },
        cyanNeon: '#00f2fe',
        pinkNeon: '#ff2a85',
        greenNeon: '#00ff87',
        purpleNeon: '#9d4edd'
      },
      fontFamily: {
        mono: ['Fira Code', 'JetBrains Mono', 'Menlo', 'monospace'],
        sans: ['Inter', 'Outfit', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
