import React, { useState } from 'react';
import { ArrowRight, Bot, Sparkles, Send, Workflow, Database, Search, GitMerge } from 'lucide-react';
import { classifyIntentAndRoute } from '../services/llmEngine';

export default function OrchestratorBar({ onRedirect, activeAgent }) {
  const [promptInput, setPromptInput] = useState('');
  const [isRouting, setIsRouting] = useState(false);
  const [routingReason, setRoutingReason] = useState(null);

  const handleRouteSubmit = async (e) => {
    e.preventDefault();
    if (!promptInput.trim()) return;

    setIsRouting(true);
    setRoutingReason('Analyzing intent with Smart Router...');

    // Simulate smart classification delay
    setTimeout(async () => {
      const { targetAgent, reasoning } = await classifyIntentAndRoute(promptInput);
      setRoutingReason(reasoning);
      
      setTimeout(() => {
        onRedirect(targetAgent, promptInput, reasoning);
        setIsRouting(false);
        setRoutingReason(null);
      }, 1000);
    }, 600);
  };

  const setPreset = (text) => {
    setPromptInput(text);
  };

  return (
    <section className="bg-gradient-to-b from-[#07090e] via-[#0b0f19] to-[#07090e] border-b border-slate-800/80 py-5 px-4 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="glass-card p-4 lg:p-5 rounded-2xl border border-cyanNeon/20 relative overflow-hidden">
          
          {/* Top Label */}
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-cyanNeon animate-ping" />
              <span className="text-xs font-mono font-semibold text-cyanNeon uppercase tracking-wider flex items-center gap-1.5">
                <Workflow className="w-3.5 h-3.5" /> SMART INTENT ROUTER & REDIRECTOR
              </span>
            </div>
            <span className="text-[11px] font-mono text-slate-400">
              Type any query — Router automatically redirects to Agent 01, 02, or 03
            </span>
          </div>

          {/* Form Input */}
          <form onSubmit={handleRouteSubmit} className="flex gap-2">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <Bot className="w-5 h-5 text-cyanNeon" />
              </div>
              <input
                type="text"
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                placeholder="Ask database ('Top products by stock'), Ask RAG ('How does vector index work?'), or Summarize text..."
                className="w-full pl-11 pr-4 py-3 bg-[#07090e] border border-slate-700/80 focus:border-cyanNeon rounded-xl text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyanNeon font-mono transition-all"
              />
            </div>
            <button
              type="submit"
              disabled={isRouting || !promptInput.trim()}
              className="px-6 py-3 rounded-xl bg-cyanNeon hover:bg-cyan-400 text-black font-bold font-mono text-xs uppercase tracking-wider flex items-center gap-2 transition-all disabled:opacity-50 glow-cyan active:scale-95 shrink-0"
            >
              {isRouting ? (
                <>
                  <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  <span>Redirecting...</span>
                </>
              ) : (
                <>
                  <span>Execute Router</span>
                  <Send className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Presets Quick Redirect Buttons */}
          <div className="flex flex-wrap items-center gap-2 mt-3 text-xs font-mono text-slate-400">
            <span className="text-slate-500 text-[11px]">Quick Tests:</span>
            <button
              onClick={() => setPreset("How many orders were shipped to USA and what is the total spend?")}
              className="px-2.5 py-1 rounded-md bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-all flex items-center gap-1 text-[11px]"
            >
              <Database className="w-3 h-3 text-cyanNeon" /> SQL: Customer orders
            </button>
            <button
              onClick={() => setPreset("How does HNSW cosine similarity search compare to sparse TF-IDF?")}
              className="px-2.5 py-1 rounded-md bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-all flex items-center gap-1 text-[11px]"
            >
              <Search className="w-3 h-3 text-pinkNeon" /> RAG: HNSW cosine specs
            </button>
            <button
              onClick={() => setPreset("Summarize the LLM engineering log doc into a 6-step prompt chain with executive tone")}
              className="px-2.5 py-1 rounded-md bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition-all flex items-center gap-1 text-[11px]"
            >
              <GitMerge className="w-3 h-3 text-greenNeon" /> Chain: 6-step summary
            </button>
          </div>

          {/* Active Redirection Overlay */}
          {routingReason && (
            <div className="mt-3 p-3 bg-cyanNeon/10 border border-cyanNeon/40 rounded-xl text-xs font-mono text-cyanNeon flex items-center gap-3 animate-pulse">
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>{routingReason}</span>
            </div>
          )}

        </div>
      </div>
    </section>
  );
}
