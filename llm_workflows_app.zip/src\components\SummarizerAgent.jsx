import React, { useState, useEffect } from 'react';
import { GitMerge, Sliders, CheckCircle2, ChevronDown, ChevronUp, Play, ArrowRight, ShieldCheck, Sparkles, Layers } from 'lucide-react';
import { runSummarizerChain } from '../services/llmEngine';

export default function SummarizerAgent({ initialPrompt, onHandoff }) {
  const [sourceText, setSourceText] = useState(
    initialPrompt || 
    `Applied LLM Engineering — Live Build Log: Modern production LLM workflows rely on three primary orchestration patterns: Text-to-SQL, RAG-Based Q&A, and Prompt Chaining. Text-to-SQL embeds questions, retrieves relevant tables from a 7-table catalog, generates SQLite queries, executes them against WASM SQLite, and self-repairs if execution fails. RAG-Based Q&A indexes documents into a 3072-dimension vector space, retrieves passages via HNSW cosine similarity, and grounds responses solely in retrieved context with adjustable top-k (3/5/8). Prompt-Chain Summarizer splits summarization into six inspectable steps: Normalize, Extract facts, Outline, Draft, Critique, and Polish. Tone and length controls steer generation while Critique audits against facts to eliminate hallucinations.`
  );

  // Configurable Output Controls (PDF Page 4)
  const [tone, setTone] = useState('executive'); // neutral, executive, technical, friendly
  const [length, setLength] = useState('standard'); // tight, standard, detailed
  
  const [chainResult, setChainResult] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [expandedStep, setExpandedStep] = useState(6); // Default expand final polish step

  useEffect(() => {
    if (initialPrompt) {
      setSourceText(initialPrompt);
      handleExecuteChain(initialPrompt, tone, length);
    } else {
      handleExecuteChain(sourceText, tone, length);
    }
  }, [initialPrompt]);

  const handleExecuteChain = async (textVal = sourceText, toneVal = tone, lengthVal = length) => {
    setIsProcessing(true);
    await new Promise(r => setTimeout(r, 500));
    const result = await runSummarizerChain(textVal, toneVal, lengthVal);
    setChainResult(result);
    setIsProcessing(false);
  };

  const steps = [
    { num: 1, name: 'Normalize', key: 'step1_normalize', desc: 'Strip noise, fix structure, keep every fact.' },
    { num: 2, name: 'Extract facts', key: 'step2_facts', desc: 'Pull atomic claims, entities, and numbers.' },
    { num: 3, name: 'Outline', key: 'step3_outline', desc: 'Group the facts into a skeleton for summary.' },
    { num: 4, name: 'Draft', key: 'step4_draft', desc: 'Write the first summary from the outline only.' },
    { num: 5, name: 'Critique', key: 'step5_critique', desc: 'Audit draft for hallucination, omissions, bloat.' },
    { num: 6, name: 'Polish', key: 'step6_polish', desc: 'Apply critique and hit target tone and length.' }
  ];

  return (
    <div className="space-y-6">
      
      {/* Header Banner matching PDF Page 4 & 5 */}
      <div className="glass-card p-6 rounded-2xl border border-greenNeon/30 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-mono font-bold text-greenNeon bg-greenNeon/10 px-2 py-0.5 rounded border border-greenNeon/30">
                03 · DECOMPOSED PROMPT CHAIN
              </span>
              <span className="text-xs font-mono text-slate-400">ask-any-data-33.lovable.app/summarize</span>
            </div>
            <h2 className="text-2xl font-extrabold text-white font-mono tracking-tight">Prompt-Chain Summarizer</h2>
            <p className="text-xs font-mono text-greenNeon/80 mt-1">
              ▶ six narrow, inspectable links
            </p>
            <p className="text-sm text-slate-300 mt-2 max-w-2xl">
              One giant prompt hallucinates. This chain splits the job into six narrow prompts — each consuming the previous link's output, leaving every intermediate artifact open for inspection.
            </p>
          </div>

          <button
            onClick={() => handleExecuteChain(sourceText, tone, length)}
            disabled={isProcessing}
            className="px-6 py-3 rounded-xl bg-greenNeon hover:bg-green-400 text-black font-bold font-mono text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all glow-green disabled:opacity-50 shrink-0"
          >
            <Play className="w-4 h-4" />
            <span>Execute 6-Step Chain</span>
          </button>
        </div>
      </div>

      {/* Configurable Controls Bar matching PDF Page 4 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Tone Controls */}
        <div className="glass-card p-4 rounded-xl border border-slate-800 space-y-2">
          <label className="text-xs font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-greenNeon" /> Tone Control:
          </label>
          <div className="flex flex-wrap gap-2">
            {['neutral', 'executive', 'technical', 'friendly'].map(t => (
              <button
                key={t}
                onClick={() => {
                  setTone(t);
                  handleExecuteChain(sourceText, t, length);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono capitalize transition-all ${
                  tone === t
                    ? 'bg-greenNeon text-black font-bold glow-green'
                    : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Length Controls */}
        <div className="glass-card p-4 rounded-xl border border-slate-800 space-y-2">
          <label className="text-xs font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-greenNeon" /> Length Control:
          </label>
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'tight', label: 'Tight (~80w)' },
              { id: 'standard', label: 'Standard (~160w)' },
              { id: 'detailed', label: 'Detailed (~320w)' }
            ].map(l => (
              <button
                key={l.id}
                onClick={() => {
                  setLength(l.id);
                  handleExecuteChain(sourceText, tone, l.id);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
                  length === l.id
                    ? 'bg-greenNeon text-black font-bold glow-green'
                    : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
                }`}
              >
                {l.label}
              </button>
            ))}
          </div>
        </div>

      </div>

      {/* Source Text Area */}
      <div className="glass-card p-4 rounded-xl border border-slate-800 space-y-2">
        <label className="text-xs font-mono text-slate-400 uppercase tracking-wider">
          Source Document Input:
        </label>
        <textarea
          rows={4}
          value={sourceText}
          onChange={(e) => setSourceText(e.target.value)}
          className="w-full p-3 bg-[#07090e] border border-slate-700 rounded-lg text-xs font-mono text-slate-200 focus:border-greenNeon focus:outline-none"
        />
      </div>

      {/* 6 Inspectable Narrow Steps Pipeline Accordion */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-mono font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <GitMerge className="w-4 h-4 text-greenNeon" /> 6 Sequential Inspectable Links
          </h3>
          <span className="text-xs font-mono text-slate-400">Step 2 Fact List is Ground Truth for Step 5 Audit</span>
        </div>

        {steps.map((step) => {
          const isExpanded = expandedStep === step.num;
          const stepData = chainResult ? chainResult[step.key] : null;

          return (
            <div
              key={step.num}
              className={`glass-card rounded-xl border transition-all ${
                isExpanded ? 'border-greenNeon/40 bg-greenNeon/5' : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              {/* Step Header */}
              <button
                onClick={() => setExpandedStep(isExpanded ? null : step.num)}
                className="w-full p-4 flex items-center justify-between text-left"
              >
                <div className="flex items-center gap-3">
                  <span className={`w-7 h-7 rounded-full font-mono font-bold text-xs flex items-center justify-center ${
                    isExpanded ? 'bg-greenNeon text-black glow-green' : 'bg-slate-800 text-slate-300'
                  }`}>
                    {step.num}
                  </span>
                  <div>
                    <span className="text-xs font-mono font-bold text-slate-200 mr-2">{step.name}</span>
                    <span className="text-[11px] text-slate-400">{step.desc}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {step.num === 5 && (
                    <span className="text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> Ground Truth Audit
                    </span>
                  )}
                  {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </div>
              </button>

              {/* Step Content */}
              {isExpanded && (
                <div className="px-4 pb-4 pt-1 border-t border-slate-800/80">
                  <div className="bg-[#07090e] p-4 rounded-lg border border-slate-800 text-xs font-mono text-slate-200 leading-relaxed overflow-x-auto">
                    {Array.isArray(stepData) ? (
                      <ul className="space-y-1.5">
                        {stepData.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-cyan-300">
                            <span className="text-slate-500">•</span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <pre className="whitespace-pre-wrap">{stepData || 'Executing link prompt...'}</pre>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Final Summary Output Card */}
      {chainResult && (
        <div className="glass-card p-6 rounded-2xl border border-greenNeon/40 bg-gradient-to-b from-[#0b0f19] to-[#07090e] space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-greenNeon uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4" /> Final Grounded Summary Artifact (Tone: {tone}, Length: {length})
            </span>
            <span className="text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> Critique Audit Passed
            </span>
          </div>

          <p className="text-sm font-mono text-slate-100 leading-relaxed bg-[#07090e] p-4 rounded-xl border border-slate-800">
            {chainResult.step6_polish}
          </p>

          {/* Hand-off Redirect Button */}
          <div className="flex justify-end pt-2">
            <button
              onClick={() => onHandoff('rag', `Index this polished summary into RAG Vector Store:\n${chainResult.step6_polish}`)}
              className="px-3.5 py-1.5 rounded-lg bg-pinkNeon/15 hover:bg-pinkNeon/25 text-pinkNeon border border-pinkNeon/40 text-xs font-mono font-bold flex items-center gap-1.5 transition-all"
            >
              <span>Redirect Summary to RAG Index</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
