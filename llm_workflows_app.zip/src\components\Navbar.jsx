import React from 'react';
import { Database, Search, GitMerge, Download, Key, Sparkles, ArrowRightLeft } from 'lucide-react';
import { createCodebaseZip } from '../services/zipExporter';

export default function Navbar({ activeAgent, setActiveAgent, onOpenApiKeyModal, isSimulated }) {
  return (
    <header className="border-b border-slate-800 bg-[#07090e]/90 backdrop-blur-md sticky top-0 z-40 px-4 lg:px-8 py-3">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Brand Title matching PDF log header */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyanNeon via-purpleNeon to-pinkNeon p-[2px] flex items-center justify-center glow-cyan">
            <div className="w-full h-full bg-[#0b0f19] rounded-[6px] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-cyanNeon" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono tracking-widest text-cyanNeon uppercase font-semibold">APPLIED LLM ENGINEERING</span>
              <span className="text-[10px] bg-cyanNeon/10 text-cyanNeon border border-cyanNeon/30 px-1.5 py-0.5 rounded font-mono">LIVE BUILD LOG</span>
            </div>
            <h1 className="text-lg font-extrabold text-white tracking-tight flex items-center gap-2 font-mono">
              LLM Workflows <span className="text-slate-500 font-normal">— 3 Live Experiments</span>
            </h1>
          </div>
        </div>

        {/* Agent Redirect Tabs */}
        <nav className="flex items-center gap-1 bg-[#0b0f19] p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveAgent('sql')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold font-mono transition-all ${
              activeAgent === 'sql'
                ? 'bg-cyanNeon/15 text-cyanNeon border border-cyanNeon/40 glow-cyan'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>01 · Text-to-SQL</span>
          </button>

          <button
            onClick={() => setActiveAgent('rag')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold font-mono transition-all ${
              activeAgent === 'rag'
                ? 'bg-pinkNeon/15 text-pinkNeon border border-pinkNeon/40 glow-pink'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Search className="w-3.5 h-3.5" />
            <span>02 · RAG Q&A</span>
          </button>

          <button
            onClick={() => setActiveAgent('summarizer')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold font-mono transition-all ${
              activeAgent === 'summarizer'
                ? 'bg-greenNeon/15 text-greenNeon border border-greenNeon/40 glow-green'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <GitMerge className="w-3.5 h-3.5" />
            <span>03 · Prompt-Chain</span>
          </button>
        </nav>

        {/* Action Controls: API Key & Code ZIP Export */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenApiKeyModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-300 transition-all"
            title="Configure Gemini or OpenAI API Key"
          >
            <Key className="w-3.5 h-3.5 text-yellow-400" />
            <span>{isSimulated ? 'Engine: Offline Simulator' : 'API Configured'}</span>
          </button>

          <button
            onClick={createCodebaseZip}
            className="flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold font-mono bg-gradient-to-r from-cyanNeon to-purpleNeon text-black hover:opacity-90 transition-all shadow-md active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Download Code ZIP</span>
          </button>
        </div>

      </div>
    </header>
  );
}
